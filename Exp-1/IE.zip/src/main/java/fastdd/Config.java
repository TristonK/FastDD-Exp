package fastdd;

/**
 * @author tristonK 2023/6/24
 */
public class Config {
    public static int PliShardLength = 1000;
    public static boolean OutputDD2File = false;
    public static boolean OutputDDFlag = false;
    public static boolean OutputPredicateFlag = false;
    public static boolean OutputDFSet = false;
    public static boolean NeedRightAlwaysTrueDD = true;
    public static boolean TestMD = false;
    public static boolean TestMultiThread = true;
    public static int ThreadSize = 6;
}
