# IE-Hybrid

## Introduction

IE-Hybrid is a solution for Differential Dependency discovery. 

## Requirements

* Java 11 or later
* Maven 3.1.0 or later

## How To Run

Follow the instructions [here](https://github.com/TristonK/FastDD-Exp/tree/main/Exp-1)